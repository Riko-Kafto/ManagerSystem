﻿using ManagerSystem.BLL;
using ManagerSystem.DAL;
using System;
using System.Data;
using System.Windows.Forms;

namespace ManagerSystem
{
    public enum ModeForm2 { AddData, EditData }

    public partial class Form2 : Form
    {
        private ModeForm2 _mode;

        private Form2() => InitializeComponent();

        private ModeForm2 Mode
        {
            get => _mode;
            set
            {
                _mode = value;
                switch (Mode)
                {
                    case ModeForm2.AddData:
                        // Выполняется сразу
                        break;

                    case ModeForm2.EditData:
                        // Выполняется сразу
                        break;
                }
            }
        }

        public Form2(ModeForm2 mode)
            : this()
            => this.Mode = mode;

        userBLL u = new userBLL();
        userDAL dal = new userDAL();


        //
        public static string loggedInUser;

        string imageName = "no-image.jpg";

        private void btnSave_Click(object sender, EventArgs e)
        {
            bool success;
            switch (Mode)
            {
                case ModeForm2.AddData:
                    u.first_name = txtFirstName.Text;
                    u.last_name = txtLastName.Text;
                    u.email = txtEmail.Text;
                    u.contact = txtContact.Text;
                    u.gender = txtGender.Text;
                    u.address = txtAddress.Text;
                    u.image = imageName;

                    success = dal.Insert(u);

                    if (success == true)
                    {
                        MessageBox.Show("New User added Successfully.");

                        Form1 f1 = Owner as Form1;

                        DataTable dt = dal.Select();
                        f1.dataGridView1.DataSource = dt;

                        Close();
                    }
                    else
                    {
                        MessageBox.Show("Failed to Add New User.");
                    }

                    break;

                case ModeForm2.EditData:
                    loggedInUser = u.first_name;

                    u.id = int.Parse(txtID.Text);
                    u.first_name = txtFirstName.Text;
                    u.last_name = txtLastName.Text;
                    u.email = txtEmail.Text;
                    u.contact = txtContact.Text;
                    u.gender = txtGender.Text;
                    u.address = txtAddress.Text;
                    u.image = imageName;

                    success = dal.Update(u);

                    if (success == true)
                    {
                        MessageBox.Show("User Update Successfully.");

                        Form1 f1 = Owner as Form1;

                        DataTable dt = dal.Select();
                        f1.dataGridView1.DataSource = dt;

                        Close();
                    }

                    break;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}