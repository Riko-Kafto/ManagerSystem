﻿using ManagerSystem.BLL;
using ManagerSystem.DAL;
using System;
using System.Data;
using System.Windows.Forms;

namespace ManagerSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        userBLL u = new userBLL();
        userDAL dal = new userDAL();

        private void Button_Click(object sender, EventArgs e)
        {
            if (sender is Button butt)
            {
                if (butt == button1)
                {
                    //Form2 f2 = new Form2();
                    //f2.txtID.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                    new Form2(ModeForm2.AddData).Show(this);
                }

                else if (butt == button2)
                {
                    string loggedInUser = Form2.loggedInUser;
                    userBLL usr = dal.GetIDFromUsername(loggedInUser);
                    new Form2(ModeForm2.EditData).Show(this);
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DataTable dt = dal.Select();
            dataGridView1.DataSource = dt;
        }
    }
}